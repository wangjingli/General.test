﻿function addRole() { }
//查询
function Query() {
    var $from = $("#QuerySection").serialize();
    $("#QuerySection").submit();
}
//删除
function Deletefun() {
    var idlist = $("#TableBody input[id^='Check-id-']:checked");
    idlist.each(function () {
        alert(this.id);
    });
}
//全选
function CheckAll2() {
    var isChecked = $("#CheckAll2").is(':checked');
    //alert(isChecked);
    var idlist = $("#TableBody input[id^='Check-id-']");
    for (var i = 0; i < idlist.length; i++) {
        var element = idlist[i];
        element.checked = $("#CheckAll2")[0].checked;
    }

}

$("#bootbox-options").on('click', function () {
    bootbox.dialog({
        message: $("#myModal").html(),
        title: "为用户选择角色",
        className: "modal-darkorange",
        buttons: {
            success: {
                label: "<i class=\"icon fa fa-plus\"></i>保存",
                className: "btn-blue",
                callback: function () { alert(222); return true; }
            }
        }
    });
});