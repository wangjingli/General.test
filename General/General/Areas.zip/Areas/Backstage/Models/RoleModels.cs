﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace General.Areas.Backstage.Models
{
    public class RoleModels
    {
        public string RoleName { get; set; }

        public string RoleDescript { get; set; }

    }
}